#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: salvo
# @Date:   2015-05-18 17:35:19
# @Last Modified by:   salvo
# @Last Modified time: 2015-05-24 20:24:47


# Calculate escape velocity
from math import *


G = 6.7 * 10 ** (-14)


def escape_velocity(mass, radius):
    velocity = 0

    # velocity = sqrt(2 * G * mass / radius)

    return velocity